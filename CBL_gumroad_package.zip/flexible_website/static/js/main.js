// Main JavaScript entry point
